// Applies "Foundation 1b" (full listing options, location search, stay rooms) to the Sheetal repository: copies the new files, makes the small edits to existing files and
// adds the packages. Run from the repository folder (C:\Users\USER\Desktop\sheetal):
//   node foundation-1b/apply.mjs --check   only checks that every edit fits this copy of the code; changes nothing
//   node foundation-1b/apply.mjs           applies it (every file it touches is first copied to .foundation-1b-backup)
//   node foundation-1b/apply.mjs --undo    puts every file back as it was before
// Safe to run twice: edits already made are skipped.
import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from "node:fs";
import { dirname, join, relative, sep } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const root = process.cwd();
const args = process.argv.slice(2);
const red = (s) => `\x1b[31m${s}\x1b[0m`, green = (s) => `\x1b[32m${s}\x1b[0m`, bold = (s) => `\x1b[1m${s}\x1b[0m`;
if (!existsSync(join(root, "backend-core", "prisma", "schema.prisma")) || !existsSync(join(root, "business", "frontend"))) {
  console.error(red("Run this from the Sheetal repository folder, e.g. cd C:\\Users\\USER\\Desktop\\sheetal"));
  process.exit(1);
}
const backupRoot = join(root, ".foundation-1b-backup");
if (!args.includes("--undo") && !existsSync(join(root, "backend-core", "src", "lib", "catalog.ts"))) {
  console.error(red("Apply Foundation 1 first (node foundation-1/apply.mjs)."));
  process.exit(1);
}

if (args.includes("--undo")) {
  const runs = existsSync(backupRoot) ? readdirSync(backupRoot).sort() : [];
  if (!runs.length) { console.error(red("Nothing to undo.")); process.exit(1); }
  const dir = join(backupRoot, runs[0]);
  const made = JSON.parse(readFileSync(join(dir, "_new-files.json"), "utf8"));
  for (const f of made) rmSync(join(root, f), { force: true });
  const walk = (d) => readdirSync(d).flatMap((n) => (statSync(join(d, n)).isDirectory() ? walk(join(d, n)) : [join(d, n)]));
  for (const f of walk(dir).filter((f) => !f.endsWith("_new-files.json"))) { const to = join(root, relative(dir, f)); mkdirSync(dirname(to), { recursive: true }); copyFileSync(f, to); }
  rmSync(backupRoot, { recursive: true, force: true });
  console.log(green("Undone: every file is back as it was. Run npm install again."));
  process.exit(0);
}

const check = args.includes("--check");
const edits = JSON.parse(readFileSync(join(here, "edits.json"), "utf8"));
const texts = new Map();
const read = (f) => { if (!texts.has(f)) texts.set(f, readFileSync(join(root, f), "utf8")); return texts.get(f); };
const problems = [];
const changed = new Set();
let skipped = 0;

for (const e of edits) {
  const path = join(root, e.file);
  if (!existsSync(path)) { problems.push(`${e.file}: file not found`); continue; }
  let text = read(e.file);
  const eol = text.includes("\r\n") ? "\r\n" : "\n";
  const fix = (s) => s.replace(/\r?\n/g, eol);
  if (e.op === "json") {
    const j = JSON.parse(text);
    let o = j;
    for (const k of e.path.slice(0, -1)) o = o[k] = o[k] || {};
    if (o[e.path.at(-1)] === e.value) { skipped++; continue; }
    o[e.path.at(-1)] = e.value;
    texts.set(e.file, JSON.stringify(j, null, 2) + eol);
    changed.add(e.file);
    continue;
  }
  const done = fix(e.done ?? e.replace);
  if (text.includes(done)) { skipped++; continue; }
  if (e.op === "append") { texts.set(e.file, text.replace(/\s*$/, "") + eol + fix(e.replace)); changed.add(e.file); continue; }
  if (e.op === "regex") {
    const re = new RegExp(e.find, "g");
    const n = (text.match(re) || []).length;
    if (n !== e.count) { problems.push(`${e.file}: expected ${e.count} matches for ${e.find}, found ${n}`); continue; }
    texts.set(e.file, text.replace(re, e.replace));
    changed.add(e.file);
    continue;
  }
  const find = fix(e.find);
  const at = text.indexOf(find);
  if (at < 0 || text.indexOf(find, at + 1) >= 0) { problems.push(`${e.file}: ${at < 0 ? "can't find" : "found twice"}: ${e.find.split("\n")[0].slice(0, 90)}`); continue; }
  texts.set(e.file, text.slice(0, at) + fix(e.replace) + text.slice(at + find.length));
  changed.add(e.file);
}

const walk = (d) => readdirSync(d).flatMap((n) => (statSync(join(d, n)).isDirectory() ? walk(join(d, n)) : [join(d, n)]));
const files = walk(join(here, "files")).map((f) => relative(join(here, "files"), f).split(sep).join("/"));

if (problems.length) {
  console.error(red(bold(`${problems.length} edit(s) don't fit this copy of the code. Nothing was changed.`)));
  for (const p of problems) console.error(red(`  - ${p}`));
  console.error("Pull the latest code (git pull) or send this list back.");
  process.exit(1);
}
console.log(`${files.length} files to copy, ${changed.size} files to edit, ${skipped} edits already made.`);
if (check) { console.log(green("Check passed: everything fits. Run again without --check to apply.")); process.exit(0); }

const stamp = new Date().toISOString().replace(/[:.]/g, "-");
const backup = join(backupRoot, stamp);
mkdirSync(backup, { recursive: true });
const keep = (f) => { if (existsSync(join(root, f)) && !existsSync(join(backup, f))) { mkdirSync(dirname(join(backup, f)), { recursive: true }); copyFileSync(join(root, f), join(backup, f)); } };
const made = [];
for (const f of files) { if (existsSync(join(root, f))) keep(f); else made.push(f); mkdirSync(dirname(join(root, f)), { recursive: true }); copyFileSync(join(here, "files", f), join(root, f)); }
for (const f of changed) { keep(f); writeFileSync(join(root, f), texts.get(f)); }
writeFileSync(join(backup, "_new-files.json"), JSON.stringify(made, null, 2));

console.log(green(bold("Foundation 1b applied.")));
console.log(`Backup of the old files: ${relative(root, backup)}  (undo: node foundation-1b/apply.mjs --undo)\n`);
console.log(bold("Next:"));
console.log("  1. Stop npm run dev and npm run dev:api (Ctrl+C), then start them again");
console.log("  2. npm run check                        lint, typecheck and all tests");
console.log("  Nothing to install and no database change this time.");
console.log("\nWhat changed: docs/foundation-1.md, section Foundation 1b");
