# Sheetal · Foundation 1b

Full built-in listing options (all 77 districts and their areas, the Kathmandu valley tol by tol, more property types,
room / bed / bathroom / amenity choices like the big booking sites), one-box location search in the listing form, stay
rooms on the website's property page, and website filters from Listing setup. Needs Foundation 1 applied first.

```powershell
cd C:\Users\USER\Desktop\sheetal
Expand-Archive -Path ".\sheetal-foundation-1b.zip" -DestinationPath . -Force
node foundation-1b/apply.mjs --check
node foundation-1b/apply.mjs
```

Then restart `npm run dev:api` and `npm run dev`, and run `npm run check`. No install, no database change.
Undo: `node foundation-1b/apply.mjs --undo`.
